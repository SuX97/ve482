#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <wait.h>
#define MAX 40
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
char *arglist[MAX];

void shift_2(char* argv[],int index){
	for(int i= index; i<=MAX - 3; i++){
		argv[i] = argv[i+2];
		
}
	argv[MAX -2] = NULL;
	argv[MAX -1] = NULL;

}

void redir_o(char *file,int flag){
	//printf("Redirect to %s\n.", file);
	int fd = 0;
	if(flag == 0){
	fd = open(file, O_WRONLY | O_CREAT |O_TRUNC, 0777);
}
	else if(flag == 1){
	fd = open(file, O_RDWR | O_APPEND | O_CREAT, 0777);

}

	dup2(fd,STDOUT_FILENO);
	close(fd);


}

void redir_i(char *file){
	freopen(file,"r",stdin);
}
void insert(char line[], int index, int flag){
	int i;
	
	if(index >= strlen(line)){
		printf("No!Too long!");
		exit(1);
}	else{
	if (flag == 0){				//> or <
	for (i = strlen(line); i>= index; i--){
		line[i+1] = line[i];
}
	line[index] = ' ';
	for (i = strlen(line); i>= index + 2; i--){
		line[i + 1] = line[i];
}
	line[index + 2] = ' ';		

	}
	else if(flag == 1){			//>>
	for (i = strlen(line); i >= index; i--) line[i+1] = line[i];
	line[index] = ' ';
	for (i = strlen(line); i >= index + 3; i--) line[i+1] = line[i];
	line[index + 3] = ' ';

}
}
}

void parse(char temp[], char *argv[]){
	temp[strlen(temp) - 1]='\0';

/****Add blank to > and >>****/
	char *ptr;
	ptr = strchr(temp, '>');
	while(ptr != NULL){
	if (temp[ptr-temp+1] != '>'){
		insert(temp ,ptr - temp,0);
		
		ptr = strchr(ptr + 2, '>');
}
	else if(temp[ptr - temp + 1] == '>'){
		insert(temp, ptr - temp, 1);
		ptr = strchr(ptr + 3, '>');
}
	else{
	printf("Fuck, wrong!\n");
	//exit(1);
}

}
/****Add blank to <****/
	char *ptr2;
	ptr2 = strchr(temp, '<');
	while(ptr2 != NULL){
	//printf("< is at:%d\n", ptr2 - temp);
	insert(temp, ptr2 - temp, 0);
	ptr2 = strchr(ptr2 + 2, '<');
}

/****Seperate with blank****/
	int i = 0;
	char *p;
	p = strtok(temp," ");
	while(p != NULL){
		argv[i++] = p;
		p = strtok(NULL, " ");
}
	argv[i] = NULL;

	//printf("Seperated by blank!\n");
}
		
int execute(char *argv[]){
	if (strcmp(argv[0], "exit") == 0){
	printf("exit\n");
	return 0;

}
	//printf("Start to fork!\n");
	pid_t pid;
	pid = fork();
	int copyFd;
	int count = 0;
/****in the fork process****/
	if(pid == 0){
	//printf("In the fork process\n");
	int i;
	for(i = 0; argv[i]!=NULL;i++){
	if( strcmp(argv[i], "<") == 0){
		if(argv[i+1] ==NULL){
			printf("No file.\n");
			exit(0);
}
		else{
			redir_i(argv[i+1]);
			shift_2(argv,i);
			i-=1;
}
}	

	else if(strcmp(argv[i], ">") == 0){
		if(argv[i+1] ==NULL){
			printf("No file.\n");
			exit(0);
}
		else{
			redir_o(argv[i+1],0);
			shift_2(argv,i);
			i-=1;
}
}

	else if(strcmp(argv[i], ">>") == 0){
		if(argv[i+1] ==NULL){
			printf("No file.\n");
			exit(0);
}
		else{
			redir_o(argv[i+1],1);
			shift_2(argv,i);
			i-=1;
}

}
}
	
/****execute!****/
	execvp(argv[0],argv);


	printf("no such file or directory\n");
	exit(0);
}

//In the father precess

	else if (pid > 0){
		wait(NULL);
}

//Fail to create process
	else{
	printf("Process creation error\n!");
}
	return 0;
}

int main(){

		while(1){
			char temp[MAX];
			printf("mumsh $ ");
			fflush(stdout);
			fgets(temp, MAX, stdin);
			parse(temp,arglist);

			if (strlen(temp) != 0){

			if(strcmp(arglist[0],"exit") == 0){
				printf("exit\n");
				return 0;
}
			execute(arglist);
			
}
			
}

}
