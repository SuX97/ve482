#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <wait.h>
#define MAX 100
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
int init_pid;
int pres_pid;
int pidA[MAX];
int flag_C = 0;
int pIndex = 0;
typedef void (*sighandler_t)(int);
sighandler_t signal(int signum, sighandler_t handler);



void handler(int sig){
	if(flag_C){
		printf("\n");
	}
	if(!flag_C){
		printf("\nmumsh $ ");
		fflush(stdout);
	}
}
int countCmd(char *argv[]){
	int count = 0;
	for(int i = 0;argv[i]!=NULL;i++){
		count ++;
	}
	return count;

}

void shift_2(char* argv[],int index){
	for(int i= index; i<=MAX - 3; i++){
		argv[i] = argv[i+2];
		
}
	argv[MAX -2] = NULL;
	argv[MAX -1] = NULL;


}

void redir_o(char *file,int flag){
	int fd = 0;
	if(flag == 0){
	fd = open(file, O_WRONLY | O_CREAT |O_TRUNC, 0777);
}
	else if(flag == 1){
	fd = open(file, O_RDWR | O_APPEND | O_CREAT, 0777);

}

	dup2(fd,STDOUT_FILENO);
	close(fd);


}

void redir_i(char *file){
	freopen(file,"r",stdin);
}

void insert(char line[], int index, int flag){
	int i;
	
	if(index >= strlen(line)){
		printf("No!Too long!");
		exit(1);
}	else{
	if (flag == 0){
	for (i = strlen(line); i>= index; i--){
		line[i+1] = line[i];
}
	line[index] = ' ';
	for (i = strlen(line); i>= index + 2; i--){
		line[i + 1] = line[i];
}
	line[index + 2] = ' ';		

	}
	else if(flag == 1){
	for (i = strlen(line); i >= index; i--) line[i+1] = line[i];
	line[index] = ' ';
	for (i = strlen(line); i >= index + 3; i--) line[i+1] = line[i];
	line[index + 3] = ' ';

}
}


}

void parse(char temp[], char *argv[]){

	char *ptr;
	ptr = strchr(temp, '>');
	while(ptr != NULL){
	if (temp[ptr-temp+1] != '>'){
		insert(temp ,ptr - temp,0);
		
		ptr = strchr(ptr + 2, '>');
}
	else if(temp[ptr - temp + 1] == '>'){
		insert(temp, ptr - temp, 1);
		ptr = strchr(ptr + 3, '>');
}
	else{
	printf("Fuck, wrong!\n");
}

}

	char *ptr2;
	ptr2 = strchr(temp, '<');
	while(ptr2 != NULL){
	insert(temp, ptr2 - temp, 0);
	ptr2 = strchr(ptr2 + 2, '<');
}

	char *ptr3;
	ptr3 = strchr(temp, '|');
	while(ptr3 != NULL){
	insert(temp, ptr3 - temp, 0);
	ptr3 = strchr(ptr3 + 2, '|');
}

	int i = 0;
	char *p;
	p = strtok(temp," ");
	while(p != NULL){
		argv[i++] = p;
		p = strtok(NULL, " ");
}
	argv[i] = NULL;

}
		


void dealRedir(char *argv[]){
	int i;
	for(i = 0; argv[i]!=NULL;i++){
	if( strcmp(argv[i], "<") == 0){
		if(argv[i+1] ==NULL){
			printf("No file.\n");
			exit(0);
}
		else{
			redir_i(argv[i+1]);
			shift_2(argv,i);

			i-=1;
}
}	

	else if(strcmp(argv[i], ">") == 0){
		if(argv[i+1] ==NULL){
			printf("No file.\n");
			exit(0);
}
		else{
			redir_o(argv[i+1],0);
			shift_2(argv,i);
			i-=1;
}
}

	else if(strcmp(argv[i], ">>") == 0){
		if(argv[i+1] ==NULL){
			printf("No file.\n");
			exit(0);
}
		else{
			redir_o(argv[i+1],1);
			shift_2(argv,i);
			i-=1;
}

}
}
}

int pwdCmd(){
	char result[255];
	if(!getcwd(result, 255)){
		printf("ERROR IN PWD\n");
		return 1;

	}
	printf("%s\n", result);
	return 0;
}


int cdCmd(char *argv[]){
	if (argv[1] == NULL || argv[2]!=NULL){
		printf("Missing or too many arguments!\n");
		return 1;
	}
	int ret = chdir(argv[1]);
	if(ret == -1){
		printf("Cd ERROR!\n");
		return 1;
	}
	return 0;


}



int piping(char *argv[], int std_in){
		int isLast = 1;
		int index = -1;
		for(int i = 0; argv[i] != NULL; i++){
			if(strcmp(argv[i], "|") == 0){
				isLast = 0;
				index = i;
				argv[i] = NULL;
				break;
			}
		}

		int fd[2];
		if(pipe(fd) == -1){
			printf("Pipe failed\n");
			return 1;
		}

		if(!isLast){
		pid_t pid;
		pid = vfork();

		char *comm[MAX];

		for(int j = 0; j<= index; j++){
		comm[j] = argv[j];
		//if (comm[j]!=NULL) printf("%s\n", comm[j]);
		} 
///////////////////////////////////////////////////
		if(pid < 0){
			printf("Fail to fork!\n");
			return 1;
		}

		if(pid == 0){
			//printf("HERE!\n");
			close(fd[0]);
			dup2(fd[1], STDOUT_FILENO);
			close(fd[1]);

			dealRedir(comm);

			execvp(comm[0],comm);		
			fclose(stdout);
			exit(0);
			return 0;
		}
		else if(pid > 0){

			dup2(fd[0],STDIN_FILENO);
			close(fd[1]);
			//close(0);
			close(fd[0]);

			piping(&argv[index+1], std_in);

			int status;
			waitpid(pid, &status, 0);
			return 0;

	}
	}
	else{
		pid_t pid;
		pid = vfork();
		if(pid < 0){
			printf("Fork fail.\n");
			return 1;
		}
		else if(pid == 0){
			close(fd[1]);
			close(fd[0]);
			dealRedir(argv);
			execvp(argv[0],argv);
			return 0;

		}
		else{
			int status;
			waitpid(pid, &status, 0);
			dup2(std_in,STDIN_FILENO);
			close(std_in);
			return 0;
		}

	}
	return 0;
}


int callPi(char *argv[]){

/////////////////////////////////////////////////////////////
	int index = -1;
	int isPipe = 0;
	int std_in = dup(STDIN_FILENO);
	for(int i = 0; argv[i] != NULL; i++){
		if(strcmp(argv[i], "|") == 0){
			index = i;
			//argv[i] = NULL;
			isPipe = 1;
			break;
		}
	}

///////////////////////////////////////////////////////////////
///
///
	if(isPipe){
		piping(argv,std_in);
		return 0;
}

	
	else if(!isPipe){
		//printf("here\n");
		pid_t pid;
		pid = fork();	
		if(pid == 0){

			dealRedir(argv);
			int result;

			result = execvp(argv[0],argv);

			if(result == -1){
				return 0;
			}
			fclose(stdout);
		}

		else if(pid > 0){
		int status;
		waitpid(pid, &status, 0);
		return 1;
		}

		else{
			printf("Error!\n");
			fflush(stdout);
		}

		return 0;
	}
/////////////////////////////////////////////////////////////////

	return 0;
}

int execute(char *argv[]){


	if(strcmp(argv[0],"cd") == 0){
	cdCmd(argv);
	return 0;
	
}

	int inFd = dup(STDIN_FILENO);
	int outFd = dup(STDOUT_FILENO);


	callPi(argv);

	dup2(inFd,STDIN_FILENO);
	dup2(outFd,STDOUT_FILENO);

return 0;
}

/*char readCmd(char temp[],char* arglist){


			return temp;

}*/

int main(){
		char *arglist[MAX];
		//char **parglist = &arglist;
		int i = 0;
		signal(SIGINT, SIG_IGN);
		char temp[MAX];
		//char *ptemp = &temp;
		init_pid = (int)getpid();
		sighandler_t fp = handler;


		while(1){

			i = 0;
			printf("mumsh $ ");
			signal(SIGINT,fp);
			fflush(stdout);

			memset(arglist,0,MAX);
			memset(temp,0,sizeof(temp));
			char ch;

			int pending1 = 0;
			int pending2 = 0;
			int pending3 = 0;
			while(1){
			ch = (char)getchar();

			if(ch == '\''){
				if(pending1 == 1 && pending2 == 0){
					pending1 = 0;
					continue;
				}
				else if(pending1 == 0 && pending2 == 0){
					pending1 = 1;
					continue;
				}

			}

			else if(ch == '\"'){
				if(pending1 == 0 && pending2 == 1){
					pending2 = 0;
					continue;
				}
				else if(pending1 == 0 && pending2 == 0){
					pending2 = 1;
					continue;
				}

			}

			else if(ch == '>' || ch == '|' || ch == '<'){
				pending3 = 1;
			}
			
			else if(ch != '|' && ch != '<' && ch != '>' && ch != '\n'){
				pending3 = 0;
			}

			else if(ch == '\n'){
				if( pending1 == 0 && pending2 == 0 && pending3 == 0){
					fflush(stdout);
					break;
				}
				else if(pending1 == 1 || pending2 ==1 || pending3 == 1){
					printf(">");
					fflush(stdout);
					continue;
				}

			}

			else if(ch == EOF){
				if(arglist[0] == NULL){
					printf("exit\n");
					return 0;
				}

			}

				//printf("%c is added to temp\n",ch );
				temp[i++] = ch;

			}

			parse(temp,arglist);

			if(strlen(temp) == 0) continue;
			flag_C = 1;
			if(strcmp(arglist[0],"exit") == 0){
				printf("exit\n");
				return 0;
}
			execute(arglist);
			flag_C = 0;

}
}


