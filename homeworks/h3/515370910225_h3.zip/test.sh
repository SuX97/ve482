#/bin/bash

clang hw3.c
./a.out rand_int.txt dec
